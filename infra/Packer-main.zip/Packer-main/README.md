# Packer-

### Commands to run ami through packer
packer init .
packer fmt .
packer init .
packer build .