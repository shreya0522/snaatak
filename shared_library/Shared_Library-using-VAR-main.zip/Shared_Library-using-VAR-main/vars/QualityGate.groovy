def call() {
    waitForQualityGate abortPipeline: true
}
