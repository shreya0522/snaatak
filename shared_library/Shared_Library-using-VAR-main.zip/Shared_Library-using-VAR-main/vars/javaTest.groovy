def call(){
    echo "Executing java test"
    sh 'mvn test'
}