def call(name){
    echo "Hey, ${name} how are you..?"
}