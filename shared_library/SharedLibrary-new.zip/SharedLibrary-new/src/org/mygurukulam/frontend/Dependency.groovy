package org.mygurukulam.frontend

def install() {
    sh 'npm i'
}

return this